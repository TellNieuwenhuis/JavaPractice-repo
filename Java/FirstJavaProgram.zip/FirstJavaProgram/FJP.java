package FirstJavaProgram;

public class FJP {
    public static void main(String[] args){
        System.out.println("My Name is Tell Nieuwenhuis");
        System.out.println("I am 36 years old");
        System.out.println("My homwtown is Stapleton, Ne");
    }
}
